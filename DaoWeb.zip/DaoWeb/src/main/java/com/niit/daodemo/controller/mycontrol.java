package com.niit.daodemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.niit.Daosample.model.Book;
import com.niit.Daosample.service.Bookserve;



@Controller
public class mycontrol {

	@Autowired
	private Bookserve serveobj; 
	
	
	private Book b;
	
	@GetMapping("/")
	public String listBooks(Model model) 
	{
		model.addAttribute("book",new Book());
		model.addAttribute("books",serveobj.displayBook());
		return "book";
	}
	
	@PostMapping("/book/add")
	public String addBook(@ModelAttribute("book") Book book)
	 {
		
			if(book.getBookid()!=0) 
			{
			serveobj.addServe(book);	
			}
			
		return "redirect:/"; //  to redirect to root element which calls mapping "/ "
		}
	
	@GetMapping("/remove/{bookid}")
	public String removeBook(@PathVariable("bookid") int bookid)
	{
		
		serveobj.deleteServe(bookid);
        return "redirect:/";
    }
 
	
	
}